# Chess-GUI
Chess implementation in Java
# Credits to...
Nørresundby Skakklub's [freeware Chess fonts](http://www.enpassant.dk/chess/fonteng.htm "Chess Fonts")
# How to run and compile
Compile all java files present, and then run the application by using the command java Main